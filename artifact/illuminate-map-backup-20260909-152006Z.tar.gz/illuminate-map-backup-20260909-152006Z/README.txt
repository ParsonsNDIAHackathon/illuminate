Backup of illuminate-map, including branch history and tracked/non-ignored untracked working files. Ignored files (such as dependencies and local environment files) are excluded.
Restore: git clone -b illuminate-map history.bundle restored-repo
Then extract working-tree.tar.gz into restored-repo. Apply deletions shown in status.txt, if any.
Commit: acc6744f3cf56776e88ebf65c2c027af5648ec1a
